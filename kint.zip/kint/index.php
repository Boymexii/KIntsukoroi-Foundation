<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="keywords" content="nonprofit, ngo, fundraising">
        <meta name="description" content="This is the official website of Kintsukuroi Foundation NG">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="Kintsukuroi Foundation">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">

        <title>Kintsukuroi | NON Profit | NGO | Fund Raising</title>

        <link rel="stylesheet" type="text/css" href="css/style.css">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Dancing+Script" rel="stylesheet">
        
        <link rel="icon" href="images/kint.png">
        
        <style>
            .becomevolunteer {
                height: 500px;
                background-image: url("images/volunteer.jpg");
            }
            
            /*
Fade content bs-carousel with hero headers
Code snippet by maridlcrmn (Follow me on Twitter @maridlcrmn) for Bootsnipp.com
Image credits: unsplash.com
*/

/********************************/
/*       Fade Bs-carousel       */
/********************************/
.fade-carousel {
    position: relative;
    height: 100vh;
}
.fade-carousel .carousel-inner .item {
    height: 100vh;
}
.fade-carousel .carousel-indicators > li {
    margin: 0 2px;
    background-color: #f39c12;
    border-color: #f39c12;
    opacity: .7;
}
.fade-carousel .carousel-indicators > li.active {
  width: 10px;
  height: 10px;
  opacity: 1;
}

/********************************/
/*          Hero Headers        */
/********************************/
.hero {
    position: absolute;
    top: 50%;
    left: 50%;
    z-index: 3;
    color: #fff;
    text-align: center;
    text-transform: uppercase;
    text-shadow: 1px 1px 0 rgba(0,0,0,.75);
      -webkit-transform: translate3d(-50%,-50%,0);
         -moz-transform: translate3d(-50%,-50%,0);
          -ms-transform: translate3d(-50%,-50%,0);
           -o-transform: translate3d(-50%,-50%,0);
              transform: translate3d(-50%,-50%,0);
}
.hero h1 {
    font-size: 6em;    
    font-weight: bold;
    margin: 0;
    padding: 0;
}

.fade-carousel .carousel-inner .item .hero {
    opacity: 0;
    -webkit-transition: 2s all ease-in-out .1s;
       -moz-transition: 2s all ease-in-out .1s; 
        -ms-transition: 2s all ease-in-out .1s; 
         -o-transition: 2s all ease-in-out .1s; 
            transition: 2s all ease-in-out .1s; 
}
.fade-carousel .carousel-inner .item.active .hero {
    opacity: 1;
    -webkit-transition: 2s all ease-in-out .1s;
       -moz-transition: 2s all ease-in-out .1s; 
        -ms-transition: 2s all ease-in-out .1s; 
         -o-transition: 2s all ease-in-out .1s; 
            transition: 2s all ease-in-out .1s;    
}

/********************************/
/*            Overlay           */
/********************************/
.overlay {
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: 2;
    background-color: #080d15;
    opacity: .7;
}

/********************************/
/*          Custom Buttons      */
/********************************/
.btn.btn-lg {padding: 10px 40px;}
.btn.btn-hero,
.btn.btn-hero:hover,
.btn.btn-hero:focus {
    color: #f5f5f5;
    background-color: #1abc9c;
    border-color: #1abc9c;
    outline: none;
    margin: 20px auto;
}

/********************************/
/*       Slides backgrounds     */
/********************************/
.fade-carousel .slides .slide-1, 
.fade-carousel .slides .slide-2,
.fade-carousel .slides .slide-3,
.fade-carousel .slides .slide-4 {
  height: 100vh;
  background-size: cover;
  background-position: center center;
  background-repeat: no-repeat;
}
.fade-carousel .slides .slide-1 {
  background-image: url(images/IMG_8093.JPG);
}
.fade-carousel .slides .slide-2 {
  background-image: url(images/IMG_8298.JPG);
}
.fade-carousel .slides .slide-3 {
  background-image: url(images/volunteer.jpg);
}
.fade-carousel .slides .slide-4 {
  background-image: url(images/IMG_9077.JPG);
}

/********************************/
/*          Media Queries       */
/********************************/
@media screen and (min-width: 980px){
    .hero { width: 980px; }    
}
@media screen and (max-width: 640px){
    .hero h1 { font-size: 4em; }    
}
        </style>
    </head>
    
    
    <body>
        
        <!--- Navbar --->
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: #2f1010; height: 70px;">
            <div class="container topnav">

                <div
                     class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="index.php" style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px;">Kintsukuroi</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li style="margin-top: 8px;">
                            <a href="https://www.facebook.com/kintsukuroifoundation"><p style="font-size: 17px;"><i class="fa fa-facebook" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="https://www.instagram.com/kintsukuroifoundation"><p style="font-size: 17px;"><i class="fa fa-instagram" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="#"><p style="font-size: 17px;"><i class="fa fa-google-plus" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="https://twitter.com/KintsukuroiNG"><p style="font-size: 17px;"><i class="fa fa-twitter" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="#"><p style="font-size: 17px;"><i class="fa fa-linkedin" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="#"></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <button class="btn btn-default" style="background-color: transparent; color: white; margin-top: 8px; border-radius: 1px; border: 2px solid;"><a href="volunteer.php" style="color: inherit;">BECOME A MEMBER</a></button>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
        
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="margin-top: 69px; background-color: #d6b014; border-radius: 5px;">
            <div class="container topnav">

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-left" style="font-family: 'lato', sans-serif;">
                        <li>
                            <a href="index.php" style="color: white;"><b>HOME</b></a>
                        </li>
                        <li>
                            <a href="causes.php" style="color: white;">CAUSES</a>
                        </li>
                        <li>
                            <a href="#" style="color: white;">STORE</a>
                        </li>
                        <li>
                            <a href="#" style="color: white;">GALLERY</a>
                        </li>
                        <li>
                            <a href="#" style="color: white;">BLOG</a>
                        </li>
                        <li>
                            <a href="contactus.php" style="color: white;">CONTACT US</a>
                        </li>
                    </ul>
                    
                    <ul class="nav navbar-nav navbar-right" style="font-family: 'lato', sans-serif;">
                        
                    </ul>
                </div>

            </div>

        </nav>
        
        <div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel">
          <!-- Overlay -->
          <div class="overlay"></div>

          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#bs-carousel" data-slide-to="0" class="active"></li>
            <li data-target="#bs-carousel" data-slide-to="1"></li>
            <li data-target="#bs-carousel" data-slide-to="2"></li>
            <li data-target="#bs-carousel" data-slide-to="3"></li>
          </ol>

          <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <div class="item slides active">
              <div class="slide-1"></div>
              <div class="hero">
                
              </div>
            </div>
            <div class="item slides">
              <div class="slide-2"></div>
              <div class="hero">        
                <hgroup>
                    
              </div>
            </div>
            <div class="item slides">
              <div class="slide-3"></div>
              <div class="hero">        
                <hgroup>
                   
              </div>
            </div>
            <div class="item slides">
              <div class="slide-4"></div>
              <div class="hero">        
                <hgroup>
                   
              </div>
            </div>
          </div> 
        </div>
        
        
        <div class="container-fluid">
            <h2 style="margin-top: 150px; font-family: 'lato', sans-serif; font-weight: 300;" align="center">Help internally displaced persons with your little donation. <span><a href="causes.php" style="color: inherit;"><b style="text-decoration: underline; color: #2f1010;">Go Through Our Causes</b></a></span></h2>
            
            <div class="row"n style="margin-top: 65px; font-family: 'lato', sans-serif;">
                <div class="col-lg-4" align="center">
                    <p style="font-size: 18px;">Help Nigerian Children Get Their Own Homes</p>
                    <figure style="margin-top: 48px; margin-bottom: 23px;">
                        <img src="images/IMG_9077.JPG" class="img-responsive" draggable="false">
                    </figure>
                    <p style="margin-top: 82px;"><b>DONATION : <span style="color: #8e8782;">0 / ₦3,000,000</span></b></p>
                    <p style="margin-top: 20px; font-size: 13px; color: #8e8782;">Improve living style of people, who are affected by several health issues & poverty and unable to come out this situation.</p>
                    <button class="btn btn-default" style="margin-top: 12px; border-radius: 1px; border: 2px solid;"><a href="donate.php" style="color: inherit;">DONATE NOW</a></button>
                </div>
                <div class="col-lg-4" align="center">
                    <p style="font-size: 18px;">Help us to send Vegetables to Nigeria</p>
                    <figure style="margin-top: 48px; margin-bottom: 23px;">
                        <img src="images/img-slide-03.jpg" class="img-responsive" draggable="false">
                    </figure>
                    <p style="margin-top: 106px;"><b>DONATION : <span style="color: #8e8782;">0 / ₦6,000,000</span></b></p>
                    <p style="margin-top: 20px; font-size: 13px; color: #8e8782;">You can offer your support by sending vegetables that we can further send to these people in Nigeria</p>
                    <button class="btn btn-default" style="margin-top: 12px; border-radius: 1px; border: 2px solid;"><a href="donate.php" style="color: inherit;">DONATE NOW</a></button>
                </div>
                <div class="col-lg-4" align="center">
                    <p style="font-size: 18px;">Make Girls Educated To Aid Them Earn Reputed Position</p>
                    <figure style="margin-top: 23px; margin-bottom: 23px;">
                        <img src="images/IMG_8247.JPG" class="img-responsive" draggable="false">
                    </figure>
                    <p style="margin-top: 82px;"><b>DONATION : <span style="color: #8e8782;">0 / ₦10,000,000</span></b></p>
                    <p style="margin-top: 20px; font-size: 13px; color: #8e8782;">Give an opportunity to girls to become educated, so that, they can stand with boys and get a self exposure worldwide.</p>
                    <button class="btn btn-default" style="margin-top: 12px; border-radius: 1px; border: 2px solid;"><a href="donate.php" style="color: inherit;">DONATE NOW</a></button>
                </div>
            </div>
            
        </div>
        
        
        <section class="howcanyouhelp" style="background-color: #fbfaf8; margin-top: 90px; height: 600px; width: auto; font-family: 'lato', sans-serif;">
            <div class="container">
                <h2 align="center" style="font-family: 'lato', sans-serif; font-weight: 300; margin-top: 65px;">How can you help? <span><b style="text-decoration: underline; color: #2f1010;">See Below</b></span></h2>  
                
                <div class="row" style="margin-top: 65px;">
                    <div class="col-lg-6">
                        <p style="font-size: 18px;"><b>Media</b></p>
                        <p style="color: #8e8782;">Donate money anywhere & anytime to offer help in<br> Nigerians through different medias.</p>
                        
                        <p style="font-size: 18px; margin-top: 40px;"><b>Become a Volunteer</b></p>
                        <p style="color: #8e8782;">Take initiate to become a volunteer and help those people,<br> who do not have any hope for good living.</p>
                        
                        <p style="font-size: 18px; margin-top: 40px;"><b>Send Donation</b></p>
                        <p style="color: #8e8782;">Choose any medium either offline or online to send<br> donation and aid NGOs to support people who are facing<br> poverty.</p>
                    </div>
                    <div class="col-lg-6">
                        
                    </div>
                </div>
            </div>
        </section>
        
        
        <div class="becomevolunteer" style="font-family: 'lato', sans-serif;">
            <div class="volun" style="position: absolute; margin-top: 130px; margin-left: 120px;">
                <p style="color: white; font-weight: 300; font-size: 35px;">Become a <b style="text-decoration: underline; font-size: 42px;">Volunteer</b></p>
                <p style="color: white; font-size: 16px;">Spread the awareness of helping people, so that they can live a<br> normal life in the society and educate their children that everyone<br> deserves.</p>
                <button class="btn btn-default" style="margin-top: 22px; border-radius: 1px; border: 2px solid; background-color: transparent; color: white;"><a href="volunteer.php" style="color: inherit;">JOIN NOW</a></button>
            </div>
        </div>
        
        
        <div class="latestnews">
            <h2 style="margin-top: 80px; font-family: 'lato', sans-serif; font-weight: 300;" align="center">Checkout whats going on. <span><b style="text-decoration: underline; color: #2f1010;">Latest News</b></span></h2>   
            
            <div class="container">
                <div class="row" style="margin-top: 60px; font-family: 'lato', sans-serif;">
                    <div class="col-lg-4">
                        <img src="images/img-slide-04.jpg" class="img-responsive">
                        <p style="font-size: 18px; margin-top: 20px;">Fund raising initiatives</p><br>
                        <p style="font-weight: 300;">15 MAR 2017  POSTED IN : CATEGORY</p>
                        <p style="color: #727272;">Last month, fund raising initiatives were taken up and drives were launched to attract donations for the education of the underprivileged children. Many people participated in the event donated their heart out. We assure our sponsors and contributors that the money will surely bring a great difference in the lives of these children.</p>
                        <button class="btn btn-default" style="margin-top: 22px; border-radius: 1px; border: 2px solid;">READ MORE</button>
                    </div>
                    <div class="col-lg-4">
                        <img src="images/IMG_9077.JPG" class="img-responsive">
                        <p style="font-size: 18px; margin-top: 70px;">Fundraising for Nigerian unprivileged children</p>
                        <p style="font-weight: 300;">31 MAR 2017  POSTED IN : CATEGORY</p>
                        <p style="color: #727272;">We have been raising funds with great difficulty for the work that this charity does in Nigeria. We work in rural communities in Northern Nigeria and other parts and provide funding for widows to build businesses in order for them to help themselves and stimulate the local economy.</p>
                        <button class="btn btn-default" style="margin-top: 22px; border-radius: 1px; border: 2px solid;">READ MORE</button>
                    </div>
                    <div class="col-lg-4">
                        <img src="images/img-slide-06.jpg" class="img-responsive">
                        <p style="font-size: 18px; margin-top: 20px;">Bringing Change in 2017</p>
                        <!---<p style="font-weight: 300;">03 DEC 2013  POSTED IN : CATEGORY</p>
                        <p style="color: #727272;">The year 2014 was a very exciting year for us and the first half of 2015 is proving to be the same. We have taken steps through the first half of this year to expand our influence throughout the United States and the Continent of Africa.</p>--->
                        <button class="btn btn-default" style="margin-top: 22px; border-radius: 1px; border: 2px solid;">READ MORE</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="footer" style="margin-top: 150px;">
            <div class="footerbottom" style="background-color: #32302f; color: #8f8b89; height: 500px;">
                <div class="container">
                    <div class="row" style="font-family: 'lato', sans-serif; margin-top: 50px;">
                        <div class="col-lg-4">
                            <h1 style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px;"><b>Kintsukuroi</b></h1>
                            <p style="margin-top: 30px;">The word Kintsukuroi  means "The piece is more beautiful for having been broken." This organization started out with the knowledge that things happen in life that we have no control over, and the response we give to these happenings determine if we come out bitter or better.</p>
                            <p style="margin-top: 30px;"><i class="fa fa-home" aria-hidden="true"></i> No 39 Amana shopping complex, opposite Yola model primary school. Yola Township Bypass, Yola Adamawa state.</p>
                            <p><i class="fa fa-phone-square" aria-hidden="true"></i> +2348142276216, +2348149593396</p>
                            <p><i class="fa fa-envelope" aria-hidden="true"></i> kintsukuroifoundation@gmail.com</p>
                        </div>
                        <div class="col-lg-4">
                            <h1 style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px;"><b>Twitter Feed</b></h1>
                        </div>
                        <div class="col-lg-4">
                            <h1 style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px;"><b>Newsletter Signup</b></h1>
                            <p style="margin-top: 30px;">Sign up your account to check our newsletter that will undoubtedly help you acquainted with current scenario.</p>
                            <p style="margin-top: 30px;">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="email" style="background-color: transparent; border-color: #8f8b89; color: #8f8b89; height: 50px; border-radius: 1px;" placeholder="Email">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" style="background-color: transparent; height: 50px; border-radius: 1px; color: #d6b014; border-color: #d6b014;" type="button">Submit</button>
                                    </span>
                                </div>
                            </p>
                            <h1 style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px; margin-top: 30px;"><b>Follow us</b></h1>
                            <p style="font-size: 22px; margin-top: 20px;">
                                <a href="https://www.facebook.com/Kintsukuroifoundation" style="color: #8f8b89;"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="https://www.instagram.com/kintsukuroifoundation" style="color: #8f8b89;"><i class="fa fa-instagram" style="margin-left: 18px;" aria-hidden="true"></i></a>
                                <a href="#" style="color: #8f8b89;"><i class="fa fa-google-plus" style="margin-left: 18px;" aria-hidden="true"></i></a>
                                <a href="https://twitter.com/KintsukuroiNG" style="color: #8f8b89;"><i class="fa fa-twitter" style="margin-left: 18px;" aria-hidden="true"></i></a>
                                <a href="#" style="color: #8f8b89;"><i class="fa fa-linkedin" style="margin-left: 18px;" aria-hidden="true"></i></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footercopyright" style="background-color: #2a2928; color: #575352; height: 70px; font-family: 'lato', sans-serif; font-size: 18px;">
                <div class="container">
                    <p style="margin-top: 21px; position: absolute;">© Copyright 2017, Kintsukuroi Foundation. <a href="http://boymexii.github.io" target="_blank">Designed by E-tech</a></p>
                </div>
            </div>
        </div>
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
        <script src="https://use.fontawesome.com/bc670ccdd4.js"></script>
              
        <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-82643030-4', 'auto');
  ga('send', 'pageview');

</script>
    </body>
    
</html>
