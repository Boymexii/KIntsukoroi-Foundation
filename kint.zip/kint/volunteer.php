<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="keywords" content="nonprofit, ngo, fundraising">
        <meta name="description" content="This is the official website of Kintsukuroi Foundation NG">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="Kintsukuroi Foundation">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">

        <title>Volunteer</title>

        <link rel="stylesheet" type="text/css" href="css/style.css">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Dancing+Script" rel="stylesheet">
        
        <link rel="icon" href="images/kint.png">
        
        <style>
            .img {
                height: 279px;
                background-image: url("images/breadcrumb-bg.jpg");
            }
            
            .process-step {
                font-family: 'lato',sans-serif;
                font-weight: 300;
                background-color: #2f1010;
                border-radius: 50%;
                height: 126px;
                width: 126px;
                font-size: 26px;
                color: white;
                line-height: 126px;
                display: inline-block;
            }
        </style>
    </head>
    
    <body>
        
        <!--- Navbar --->
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: #2f1010; height: 70px;">
            <div class="container topnav">

                <div
                     class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="index.php" style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px;">Kintsukuroi</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li style="margin-top: 8px;">
                            <a href="#"><p style="font-size: 17px;"><i class="fa fa-facebook" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="#"><p style="font-size: 17px;"><i class="fa fa-instagram" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="#"><p style="font-size: 17px;"><i class="fa fa-google-plus" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="#"><p style="font-size: 17px;"><i class="fa fa-twitter" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="#"><p style="font-size: 17px;"><i class="fa fa-linkedin" aria-hidden="true"></i></p></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <a href="#"></a>
                        </li>
                        <li style="margin-top: 8px;">
                            <button class="btn btn-default" style="background-color: transparent; color: white; margin-top: 8px; border-radius: 1px; border: 2px solid;"><a href="volunteer.php" style="color: inherit;">BECOME A MEMBER</a></button>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
        
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="margin-top: 69px; background-color: #d6b014; border-radius: 5px;">
            <div class="container topnav">

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-left" style="font-family: 'lato', sans-serif;">
                        <li>
                            <a href="index.php" style="color: white;">HOME</a>
                        </li>
                        <li>
                            <a href="causes.php" style="color: white;">CAUSES</a>
                        </li>
                        <li>
                            <a href="#" style="color: white;">STORE</a>
                        </li>
                        <li>
                            <a href="#" style="color: white;">GALLERY</a>
                        </li>
                        <li>
                            <a href="#" style="color: white;">BLOG</a>
                        </li>
                        <li>
                            <a href="contactus.php" style="color: white;"><b>CONTACT US</b></a>
                        </li>
                    </ul>
                    
                    <ul class="nav navbar-nav navbar-right" style="font-family: 'lato', sans-serif;">
                        
                    </ul>
                </div>

            </div>

        </nav>
        
        <div class="img" style="margin-top: 100px;">
            <h2 style="position: absolute; margin-top: 90px; margin-left: 70px; font-family: 'lato', sans-serif;">Become a Volunteer</h2>
            <p style="position: absolute; margin-top: 130px; margin-left: 70px; font-family: 'lato', sans-serif;">Home / <b>Become a Volunteer</b></p>
        </div>
        
        <div class="container">
            <h2 style="margin-top: 50px; font-family: 'lato', sans-serif; font-weight: 300;" align="center">We need you, <span><a href="causes.php" style="color: inherit;"><b style="color: #2f1010;">Help Us Around</b></a></span></h2>
            
            <img src="images/help.jpg" class="img-responsive" style="margin-top: 50px;">
            
            <h2 style="margin-top: 50px; font-family: 'lato', sans-serif; font-weight: 300;" align="center">How you can apply, <span><b style="color: #2f1010;">Here Is The Process</b></span></h2>
            
            <div class="row" style="margin-top: 65px;">
                <div class="col-lg-3" align="center">
                    <div class="process-step">
                        <p align="center">Step 1</p>
                    </div>
                    <p style="font-size: 17px; font-family: 'lato', sans-serif; margin-top: 60px;">Create An Account</p>
                    <p style="font-size: 14px; font-weight: 300; font-family: 'lato', sans-serif; margin-top: 23px;">Submit your basic information including Name, Address, and Contact details (including, Gmail or Facebook Id)</p>
                </div>
                <div class="col-lg-3" align="center">
                    <div class="process-step">
                        <p align="center">Step 2</p>
                    </div>
                    <p style="font-size: 17px; font-family: 'lato', sans-serif; margin-top: 60px;">Attach Image & Signature</p>
                    <p style="font-size: 14px; font-weight: 300; font-family: 'lato', sans-serif; margin-top: 23px;">Attach your passport size picture and signature; this is for authenticity. It also eases the way for us to create identity card for us.</p>
                </div>
                <div class="col-lg-3" align="center">
                    <div class="process-step">
                        <p align="center">Step 3</p>
                    </div>
                    <p style="font-size: 17px; font-family: 'lato', sans-serif; margin-top: 60px;">Submit Eduction & Job Detail</p>
                    <p style="font-size: 14px; font-weight: 300; font-family: 'lato', sans-serif; margin-top: 23px;">Now, there is a form, where you need to add education and professional detail, so that we can easily divide our team on the basis of role.</p>
                </div>
                <div class="col-lg-3" align="center">
                    <div class="process-step">
                        <p align="center">Step 4</p>
                    </div>
                    <p style="font-size: 17px; font-family: 'lato', sans-serif; margin-top: 60px;">Download Identity Card</p>
                    <p style="font-size: 14px; font-weight: 300; font-family: 'lato', sans-serif; margin-top: 23px;">At last, check all your detailed information and click final to get your identity card. It is valid for 1 year.</p>
                </div>
            </div>
            
            <div class="button" style="margin-top: 60px;" align="center">
                <button class="btn btn-default" type="button" style="border-radius: 1px; border: 2px solid;"><b>JOIN TODAY</b></button>
            </div>
        </div>
        
         <div class="footer" style="margin-top: 100px;">
            <div class="footerbottom" style="background-color: #32302f; color: #8f8b89; height: 500px;">
                <div class="container">
                    <div class="row" style="font-family: 'lato', sans-serif; margin-top: 50px;">
                        <div class="col-lg-4">
                            <h1 style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px;"><b>Kintsukuroi</b></h1>
                            <p style="margin-top: 30px;">The word Kintsukuroi  means “The piece is more beautiful for having been broken.” This organization started out with the knowledge that things happen in life that we have no control over, and the response we give to these happenings determine if we come out bitter or better.</p>
                            <p style="margin-top: 30px;"><i class="fa fa-home" aria-hidden="true"></i> No 39 Amana shopping complex, opposite Yola model primary school. Yola Township Bypass, Yola Adamawa state.</p>
                            <p><i class="fa fa-phone-square" aria-hidden="true"></i> +2348142276216, +2348149593396</p>
                            <p><i class="fa fa-envelope" aria-hidden="true"></i> kintsukuroifoundation@gmail.com</p>
                        </div>
                        <div class="col-lg-4">
                            <h1 style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px;"><b>Twitter Feed</b></h1>
                        </div>
                        <div class="col-lg-4">
                            <h1 style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px;"><b>Newsletter Signup</b></h1>
                            <p style="margin-top: 30px;">Sign up your account to check our newsletter that will undoubtedly help you acquainted with current scenario.</p>
                            <p style="margin-top: 30px;">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="email" style="background-color: transparent; border-color: #8f8b89; color: #8f8b89; height: 50px; border-radius: 1px;" placeholder="Email">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" style="background-color: transparent; height: 50px; border-radius: 1px; color: #d6b014; border-color: #d6b014;" type="button">Submit</button>
                                    </span>
                                </div>
                            </p>
                            <h1 style="color: white; font-family: 'Dancing Script', cursive; font-size: 30px; margin-top: 8px; margin-top: 30px;"><b>Follow us</b></h1>
                            <p style="font-size: 22px; margin-top: 20px;">
                                <a href="#" style="color: #8f8b89;"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#" style="color: #8f8b89;"><i class="fa fa-instagram" style="margin-left: 18px;" aria-hidden="true"></i></a>
                                <a href="#" style="color: #8f8b89;"><i class="fa fa-google-plus" style="margin-left: 18px;" aria-hidden="true"></i></a>
                                <a href="#" style="color: #8f8b89;"><i class="fa fa-twitter" style="margin-left: 18px;" aria-hidden="true"></i></a>
                                <a href="#" style="color: #8f8b89;"><i class="fa fa-linkedin" style="margin-left: 18px;" aria-hidden="true"></i></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footercopyright" style="background-color: #2a2928; color: #575352; height: 70px; font-family: 'lato', sans-serif; font-size: 18px;">
                <div class="container">
                    <p style="margin-top: 21px; position: absolute;">© Copyright 2017, Kintsukuroi Foundation. <a href="http://boymexii.github.io" target="_blank">Designed by E-tech</a></p>
                </div>
            </div>
        </div>
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
        <script src="https://use.fontawesome.com/bc670ccdd4.js"></script>
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-82643030-4', 'auto');
  ga('send', 'pageview');

</script>
    </body>
    
</html>
